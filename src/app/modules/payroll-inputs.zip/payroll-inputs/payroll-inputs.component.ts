import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroll-inputs',
  templateUrl: './payroll-inputs.component.html',
  styleUrls: ['./payroll-inputs.component.scss']
})
export class PayrollInputsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
