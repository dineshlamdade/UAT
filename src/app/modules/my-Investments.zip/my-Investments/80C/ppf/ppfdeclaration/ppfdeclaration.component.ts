import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppfdeclaration',
  templateUrl: './ppfdeclaration.component.html',
  styleUrls: ['./ppfdeclaration.component.scss']
})
export class PPFDeclarationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    console.log('PPFDeclarationComponent');
  }

}
