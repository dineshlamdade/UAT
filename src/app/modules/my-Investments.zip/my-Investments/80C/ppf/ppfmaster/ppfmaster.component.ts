import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppfmaster',
  templateUrl: './ppfmaster.component.html',
  styleUrls: ['./ppfmaster.component.scss']
})
export class PPFMasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    console.log('PPFMasterComponent');
  }

}
