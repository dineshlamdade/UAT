import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-investments',
  templateUrl: './my-investments.component.html',
  styleUrls: ['./my-investments.component.scss']
})
export class MyInvestmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
